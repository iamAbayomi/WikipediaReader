package com.appdot.io.wikipediademo.model

class WikiQueryData {
    val pages: ArrayList<WikiPage> = ArrayList<WikiPage>()
}