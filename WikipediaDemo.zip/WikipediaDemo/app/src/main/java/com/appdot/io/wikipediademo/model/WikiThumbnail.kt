package com.appdot.io.wikipediademo.model

class WikiThumbnail {
    val source: String ? = null
    val width: Int = 0
    val height: Int = 0
}