package com.appdot.io.wikipediademo.model

class WikiResult{
    val query: WikiQueryData? =null
}